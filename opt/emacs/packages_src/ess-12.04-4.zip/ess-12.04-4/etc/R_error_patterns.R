Error:  chunk 7 (label = OP4)
Error in disp.Rnw:656:31: unexpected symbol
655: par(mgp = c(2.5, 1, 1), mar = c(0, 0, 0, 0),
         656:     plt= c(0.08, 0.9, 0.25, 0.p9
